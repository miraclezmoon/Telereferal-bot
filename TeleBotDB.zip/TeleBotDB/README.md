# Telegram Referral Bot

A powerful Telegram bot with a point-based referral system where users can invite friends to earn points and redeem prizes. Features an interactive button-based interface and comprehensive admin controls.

## Features

### 🚀 Core Functionality
- **Interactive Button Interface** - No typing required, everything is clickable
- **Referral System** - Users earn 5 points per successful referral
- **Prize System** - 5-tier reward system (25-200 points)
- **One-Click Prize Claiming** - Smart buttons appear only for available prizes
- **Anti-Fraud Protection** - Prevents self-referrals and duplicate claims

### 🎮 User Experience
- **Main Menu** with 3 clear options:
  - 📢 Get Referral Link
  - 💰 Check Points & Referral Count
  - 🎁 View & Claim Prizes
- **Real-time Updates** - Points and status update instantly
- **Mobile-Friendly** - Perfect button interface for phone users

### ⚙️ Admin Features
- **Prize Management** - Add, edit, remove, activate/deactivate prizes
- **User Administration** - Full control over user accounts
- **Database Management** - SQLite with automatic initialization

## Quick Setup

### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/telegram-referral-bot.git
cd telegram-referral-bot
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure Bot Token
Create a `.env` file:
```
TELEGRAM_BOT_TOKEN=your_bot_token_here
```

### 4. Set Admin Access
Edit `bot.py` line 50 to add your Telegram user ID:
```python
ADMIN_IDS = [your_telegram_id]  # Replace with your actual ID
```

### 5. Run the Bot
```bash
python bot.py
```

## Getting Your Bot Token

1. Message [@BotFather](https://t.me/BotFather) on Telegram
2. Send `/newbot` and follow the instructions
3. Copy the token and add it to your `.env` file

## Getting Your Telegram ID

1. Start your bot with `/start`
2. Use the `/getmyid` command
3. Copy your User ID number

## Prize System

### Default Prizes
- **Mini** - 25 points
- **Minor** - 50 points
- **Major** - 100 points
- **Grand** - 150 points
- **Legendary** - 200 points

### Admin Commands
- `/addprize [name] [points] [description]` - Add new prize
- `/editprize [id] [name] [points] [description]` - Edit existing prize
- `/removeprize [id]` - Remove prize
- `/listprizes` - View all prizes

## Database

The bot uses SQLite with automatic initialization. Four main tables:
- `users` - User accounts and point balances
- `referrals` - Referrer-referee relationships
- `prizes` - Available rewards catalog
- `claimed_prizes` - Prize redemption history

## File Structure

```
telegram-referral-bot/
├── bot.py              # Main bot application
├── requirements.txt    # Python dependencies
├── .env               # Environment variables (create this)
├── .gitignore         # Git ignore rules
└── README.md          # This file
```

## License

This project is open source and available under the MIT License.

## Support

For questions or issues, please open a GitHub issue or contact the maintainer.