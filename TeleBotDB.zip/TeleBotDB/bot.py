from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes, CallbackQueryHandler
import sqlite3
import logging
import os

# Load environment variables from .env file if it exists
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv not installed, use environment variables directly

# Set up logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# --- DB initialization ---
conn = sqlite3.connect("referrals.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, points INTEGER DEFAULT 0)")
cursor.execute("CREATE TABLE IF NOT EXISTS referrals (referrer_id INTEGER, referred_id INTEGER)")
cursor.execute("""CREATE TABLE IF NOT EXISTS prizes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    points_required INTEGER NOT NULL,
    description TEXT,
    active INTEGER DEFAULT 1
)""")
cursor.execute("CREATE TABLE IF NOT EXISTS claimed_prizes (user_id INTEGER, prize_id INTEGER, claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
conn.commit()

# Add default prizes (only on first run)
cursor.execute("SELECT COUNT(*) FROM prizes")
if cursor.fetchone()[0] == 0:
    default_prizes = [
        ("Bronze Badge", 50, "First achievement badge 🥉"),
        ("Silver Badge", 100, "Silver achievement badge 🥈"), 
        ("Gold Badge", 200, "Gold achievement badge 🥇"),
        ("Premium Access", 500, "1-month premium features access ⭐"),
        ("Special Reward", 1000, "Special reward and VIP benefits 💎")
    ]
    cursor.executemany("INSERT INTO prizes (name, points_required, description) VALUES (?, ?, ?)", default_prizes)
    conn.commit()

# Update existing Korean descriptions to English (run once)
cursor.execute("UPDATE prizes SET description = 'First achievement badge 🥉' WHERE id = 1 AND description LIKE '%번째%'")
cursor.execute("UPDATE prizes SET description = 'Silver achievement badge 🥈' WHERE id = 2 AND description LIKE '%실버%'")
cursor.execute("UPDATE prizes SET description = 'Gold achievement badge 🥇' WHERE id = 3 AND description LIKE '%골드%'")
cursor.execute("UPDATE prizes SET description = '1-month premium features access ⭐' WHERE id = 4 AND description LIKE '%프리미엄%'")
cursor.execute("UPDATE prizes SET description = 'Special reward and VIP benefits 💎' WHERE id = 5 AND description LIKE '%특별%'")
conn.commit()

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

# Admin user IDs (replace with your Telegram user ID)
ADMIN_IDS = [7371759174]  # Add your Telegram user ID here, e.g., [123456789]

# /getmyid - Get your Telegram user ID
async def get_my_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or "No username"
    first_name = update.effective_user.first_name or "No name"
    
    await update.message.reply_text(f"🆔 Your Telegram Info:\\n\\nUser ID: `{user_id}`\\nUsername: @{username}\\nName: {first_name}\\n\\n📋 Copy the User ID number to add yourself as admin!")

def is_admin(user_id):
    return user_id in ADMIN_IDS

# /start command (referral code processing)
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    user_id = update.effective_user.id
    
    # Register new user in DB
    cursor.execute("INSERT OR IGNORE INTO users (user_id, points) VALUES (?, ?)", (user_id, 0))
    conn.commit()

    if args:
        referrer_id = int(args[0])
        if referrer_id != user_id:  # Prevent self-referral
            # Check if user was already referred
            cursor.execute("SELECT COUNT(*) FROM referrals WHERE referred_id = ?", (user_id,))
            if cursor.fetchone()[0] == 0:  # Only if first time being referred
                cursor.execute("INSERT INTO referrals (referrer_id, referred_id) VALUES (?, ?)", (referrer_id, user_id))
                cursor.execute("UPDATE users SET points = points + 5 WHERE user_id = ?", (referrer_id,))
                conn.commit()
                await update.message.reply_text("🎉 Referral successful! 5 points added to your referrer!")
            else:
                await update.message.reply_text("You have already been referred by another user.")
    else:
        # Create main menu with buttons
        keyboard = [
            [InlineKeyboardButton("📢 Get My Referral Link", callback_data="get_referral")],
            [InlineKeyboardButton("💰 Check My Points", callback_data="check_points")],
            [InlineKeyboardButton("🎁 View Prizes", callback_data="view_prizes")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("🤖 Hello! Welcome to the bot.\n\nChoose an option below:", reply_markup=reply_markup)

# /getreferral → Get your own referral link
async def get_referral(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    bot_username = context.bot.username or "YourBotUsername"
    link = f"https://t.me/{bot_username}?start={user_id}"
    # Add back to menu button
    keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(f"📢 Your Referral Link:\n{link}\n\nInvite friends and earn 5 points for each successful referral!", reply_markup=reply_markup)

# /points → Check your points
async def points(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    cursor.execute("SELECT points FROM users WHERE user_id=?", (user_id,))
    result = cursor.fetchone()
    pts = result[0] if result else 0
    
    # Check number of people referred
    cursor.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (user_id,))
    referral_count = cursor.fetchone()[0]
    
    # Add back to menu button
    keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(f"💰 Current Points: {pts}\n👥 Friends Referred: {referral_count}", reply_markup=reply_markup)

# /prizes → View prize list
async def prizes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    cursor.execute("SELECT points FROM users WHERE user_id=?", (user_id,))
    result = cursor.fetchone()
    user_points = result[0] if result else 0
    
    cursor.execute("SELECT id, name, points_required, description FROM prizes WHERE active = 1 ORDER BY points_required")
    prizes_list = cursor.fetchall()
    
    if not prizes_list:
        await update.message.reply_text("No prizes currently available.")
        return
    
    message = f"🎁 Prize List (Your Points: {user_points})\n\n"
    for prize_id, name, points_req, desc in prizes_list:
        # Check if already claimed
        cursor.execute("SELECT COUNT(*) FROM claimed_prizes WHERE user_id=? AND prize_id=?", (user_id, prize_id))
        is_claimed = cursor.fetchone()[0] > 0
        
        status = ""
        if is_claimed:
            status = " ✅ Claimed"
        elif user_points >= points_req:
            status = " 🟢 Available"
        else:
            status = " 🔴 Need More Points"
            
        message += f"{prize_id}. {name} ({points_req} points){status}\n   {desc}\n\n"
    
    # Create claim buttons for available prizes
    keyboard = []
    for prize_id, name, points_req, desc in prizes_list:
        cursor.execute("SELECT COUNT(*) FROM claimed_prizes WHERE user_id=? AND prize_id=?", (user_id, prize_id))
        is_claimed = cursor.fetchone()[0] > 0
        
        if not is_claimed and user_points >= points_req:
            keyboard.append([InlineKeyboardButton(f"🎁 Claim {name}", callback_data=f"claim_{prize_id}")])
    
    keyboard.append([InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(message, reply_markup=reply_markup)

# /claim → Claim a prize
async def claim(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not context.args:
        await update.message.reply_text("Usage: /claim [prize_id]\nExample: /claim 1")
        return
    
    try:
        prize_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Please enter a valid prize ID.")
        return
    
    # Check prize information
    cursor.execute("SELECT name, points_required, description FROM prizes WHERE id=? AND active=1", (prize_id,))
    prize = cursor.fetchone()
    if not prize:
        await update.message.reply_text("Prize does not exist.")
        return
    
    name, points_req, desc = prize
    
    # Check user points
    cursor.execute("SELECT points FROM users WHERE user_id=?", (user_id,))
    result = cursor.fetchone()
    user_points = result[0] if result else 0
    
    if user_points < points_req:
        await update.message.reply_text(f"Not enough points. Required: {points_req}, You have: {user_points}")
        return
    
    # Check if already claimed
    cursor.execute("SELECT COUNT(*) FROM claimed_prizes WHERE user_id=? AND prize_id=?", (user_id, prize_id))
    if cursor.fetchone()[0] > 0:
        await update.message.reply_text("You have already claimed this prize.")
        return
    
    # Process prize claim
    cursor.execute("UPDATE users SET points = points - ? WHERE user_id = ?", (points_req, user_id))
    cursor.execute("INSERT INTO claimed_prizes (user_id, prize_id) VALUES (?, ?)", (user_id, prize_id))
    conn.commit()
    
    await update.message.reply_text(f"🎉 Congratulations!\n\nYou have successfully claimed '{name}'!\n{desc}\n\nPoints used: {points_req}\nRemaining points: {user_points - points_req}")

# --- Button Callback Handlers ---

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    if query.data == "main_menu":
        # Show main menu
        keyboard = [
            [InlineKeyboardButton("📢 Get My Referral Link", callback_data="get_referral")],
            [InlineKeyboardButton("💰 Check My Points", callback_data="check_points")],
            [InlineKeyboardButton("🎁 View Prizes", callback_data="view_prizes")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🤖 Main Menu\n\nChoose an option below:", reply_markup=reply_markup)
    
    elif query.data == "get_referral":
        # Show referral link
        bot_username = context.bot.username or "YourBotUsername"
        link = f"https://t.me/{bot_username}?start={user_id}"
        keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(f"📢 Your Referral Link:\n{link}\n\nInvite friends and earn 5 points for each successful referral!", reply_markup=reply_markup)
    
    elif query.data == "check_points":
        # Show points
        cursor.execute("SELECT points FROM users WHERE user_id=?", (user_id,))
        result = cursor.fetchone()
        pts = result[0] if result else 0
        
        cursor.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (user_id,))
        referral_count = cursor.fetchone()[0]
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(f"💰 Current Points: {pts}\n👥 Friends Referred: {referral_count}", reply_markup=reply_markup)
    
    elif query.data == "view_prizes":
        # Show prizes
        cursor.execute("SELECT points FROM users WHERE user_id=?", (user_id,))
        result = cursor.fetchone()
        user_points = result[0] if result else 0
        
        cursor.execute("SELECT id, name, points_required, description FROM prizes WHERE active = 1 ORDER BY points_required")
        prizes_list = cursor.fetchall()
        
        if not prizes_list:
            keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("No prizes currently available.", reply_markup=reply_markup)
            return
        
        message = f"🎁 Prize List (Your Points: {user_points})\n\n"
        for prize_id, name, points_req, desc in prizes_list:
            cursor.execute("SELECT COUNT(*) FROM claimed_prizes WHERE user_id=? AND prize_id=?", (user_id, prize_id))
            is_claimed = cursor.fetchone()[0] > 0
            
            status = ""
            if is_claimed:
                status = " ✅ Claimed"
            elif user_points >= points_req:
                status = " 🟢 Available"
            else:
                status = " 🔴 Need More Points"
                
            message += f"{prize_id}. {name} ({points_req} points){status}\n   {desc}\n\n"
        
        # Create claim buttons for available prizes
        keyboard = []
        for prize_id, name, points_req, desc in prizes_list:
            cursor.execute("SELECT COUNT(*) FROM claimed_prizes WHERE user_id=? AND prize_id=?", (user_id, prize_id))
            is_claimed = cursor.fetchone()[0] > 0
            
            if not is_claimed and user_points >= points_req:
                keyboard.append([InlineKeyboardButton(f"🎁 Claim {name}", callback_data=f"claim_{prize_id}")])
        
        keyboard.append([InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(message, reply_markup=reply_markup)
    
    elif query.data == "get_my_id":
        # Show user ID
        username = query.from_user.username or "No username"
        first_name = query.from_user.first_name or "No name"
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(f"🆔 Your Telegram Info:\n\nUser ID: `{user_id}`\nUsername: @{username}\nName: {first_name}\n\n📋 Copy the User ID number to add yourself as admin!", reply_markup=reply_markup)
    
    elif query.data.startswith("claim_"):
        # Handle prize claiming
        prize_id = int(query.data.split("_")[1])
        
        # Check prize information
        cursor.execute("SELECT name, points_required, description FROM prizes WHERE id=? AND active=1", (prize_id,))
        prize = cursor.fetchone()
        if not prize:
            await query.edit_message_text("Prize does not exist.")
            return
        
        name, points_req, desc = prize
        
        # Check user points
        cursor.execute("SELECT points FROM users WHERE user_id=?", (user_id,))
        result = cursor.fetchone()
        user_points = result[0] if result else 0
        
        if user_points < points_req:
            keyboard = [[InlineKeyboardButton("🔙 Back to Prizes", callback_data="view_prizes")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(f"Not enough points. Required: {points_req}, You have: {user_points}", reply_markup=reply_markup)
            return
        
        # Check if already claimed
        cursor.execute("SELECT COUNT(*) FROM claimed_prizes WHERE user_id=? AND prize_id=?", (user_id, prize_id))
        if cursor.fetchone()[0] > 0:
            keyboard = [[InlineKeyboardButton("🔙 Back to Prizes", callback_data="view_prizes")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("You have already claimed this prize.", reply_markup=reply_markup)
            return
        
        # Process prize claim
        cursor.execute("UPDATE users SET points = points - ? WHERE user_id = ?", (points_req, user_id))
        cursor.execute("INSERT INTO claimed_prizes (user_id, prize_id) VALUES (?, ?)", (user_id, prize_id))
        conn.commit()
        
        keyboard = [
            [InlineKeyboardButton("🎁 View Prizes", callback_data="view_prizes")],
            [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(f"🎉 Congratulations!\n\nYou have successfully claimed '{name}'!\n{desc}\n\nPoints used: {points_req}\nRemaining points: {user_points - points_req}", reply_markup=reply_markup)

# --- Admin Commands ---

# /addprize - Add a new prize (Admin only)
async def add_prize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ Access denied. Admin only command.")
        return
    
    if len(context.args) < 3:
        await update.message.reply_text("Usage: /addprize [name] [points] [description]\nExample: /addprize \"VIP Badge\" 300 \"Exclusive VIP status badge\"")
        return
    
    try:
        name = context.args[0]
        points_required = int(context.args[1])
        description = " ".join(context.args[2:])
        
        cursor.execute("INSERT INTO prizes (name, points_required, description) VALUES (?, ?, ?)", 
                      (name, points_required, description))
        conn.commit()
        
        await update.message.reply_text(f"✅ Prize added successfully!\n\nName: {name}\nPoints: {points_required}\nDescription: {description}")
    
    except ValueError:
        await update.message.reply_text("❌ Invalid points value. Please use a number.")
    except Exception as e:
        await update.message.reply_text(f"❌ Error adding prize: {str(e)}")

# /editprize - Edit an existing prize (Admin only)
async def edit_prize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ Access denied. Admin only command.")
        return
    
    if len(context.args) < 4:
        await update.message.reply_text("Usage: /editprize [prize_id] [name] [points] [description]\nExample: /editprize 1 \"Updated Badge\" 150 \"New description\"")
        return
    
    try:
        prize_id = int(context.args[0])
        name = context.args[1]
        points_required = int(context.args[2])
        description = " ".join(context.args[3:])
        
        # Check if prize exists
        cursor.execute("SELECT COUNT(*) FROM prizes WHERE id = ?", (prize_id,))
        if cursor.fetchone()[0] == 0:
            await update.message.reply_text("❌ Prize ID not found.")
            return
        
        cursor.execute("UPDATE prizes SET name = ?, points_required = ?, description = ? WHERE id = ?", 
                      (name, points_required, description, prize_id))
        conn.commit()
        
        await update.message.reply_text(f"✅ Prize updated successfully!\n\nID: {prize_id}\nName: {name}\nPoints: {points_required}\nDescription: {description}")
    
    except ValueError:
        await update.message.reply_text("❌ Invalid prize ID or points value. Please use numbers.")
    except Exception as e:
        await update.message.reply_text(f"❌ Error editing prize: {str(e)}")

# /removeprize - Remove/disable a prize (Admin only)
async def remove_prize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ Access denied. Admin only command.")
        return
    
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /removeprize [prize_id]\nExample: /removeprize 3")
        return
    
    try:
        prize_id = int(context.args[0])
        
        # Check if prize exists
        cursor.execute("SELECT name FROM prizes WHERE id = ? AND active = 1", (prize_id,))
        result = cursor.fetchone()
        if not result:
            await update.message.reply_text("❌ Prize ID not found or already inactive.")
            return
        
        prize_name = result[0]
        cursor.execute("UPDATE prizes SET active = 0 WHERE id = ?", (prize_id,))
        conn.commit()
        
        await update.message.reply_text(f"✅ Prize '{prize_name}' (ID: {prize_id}) has been deactivated.")
    
    except ValueError:
        await update.message.reply_text("❌ Invalid prize ID. Please use a number.")
    except Exception as e:
        await update.message.reply_text(f"❌ Error removing prize: {str(e)}")

# /listprizes - List all prizes including inactive ones (Admin only)
async def list_all_prizes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ Access denied. Admin only command.")
        return
    
    cursor.execute("SELECT id, name, points_required, description, active FROM prizes ORDER BY id")
    prizes_list = cursor.fetchall()
    
    if not prizes_list:
        await update.message.reply_text("No prizes in database.")
        return
    
    message = "🔧 Admin - All Prizes:\n\n"
    for prize_id, name, points_req, desc, active in prizes_list:
        status = "🟢 Active" if active else "🔴 Inactive"
        message += f"{prize_id}. {name} ({points_req} points) - {status}\n   {desc}\n\n"
    
    await update.message.reply_text(message)

# /addadmin - Add a new admin (Admin only)
async def add_admin_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ Access denied. Admin only command.")
        return
    
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /addadmin [user_id]\nExample: /addadmin 123456789")
        return
    
    try:
        new_admin_id = int(context.args[0])
        if new_admin_id not in ADMIN_IDS:
            ADMIN_IDS.append(new_admin_id)
            await update.message.reply_text(f"✅ User {new_admin_id} added as admin.\n\nNote: This is temporary. Add to ADMIN_IDS list in code for permanent access.")
        else:
            await update.message.reply_text("User is already an admin.")
    
    except ValueError:
        await update.message.reply_text("❌ Invalid user ID. Please use a number.")

# --- Bot execution ---
def main():
    if not TOKEN:
        print("⚠️  Please set up bot token!")
        print("TELEGRAM_BOT_TOKEN environment variable is not set.")
        return
    
    app = Application.builder().token(TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("getreferral", get_referral))
    app.add_handler(CommandHandler("points", points))
    app.add_handler(CommandHandler("prizes", prizes))
    app.add_handler(CommandHandler("claim", claim))
    
    # Button callback handler
    app.add_handler(CallbackQueryHandler(button_callback))
    
    # Admin commands
    app.add_handler(CommandHandler("addprize", add_prize))
    app.add_handler(CommandHandler("editprize", edit_prize))
    app.add_handler(CommandHandler("removeprize", remove_prize))
    app.add_handler(CommandHandler("listprizes", list_all_prizes))
    app.add_handler(CommandHandler("addadmin", add_admin_user))
    app.add_handler(CommandHandler("getmyid", get_my_id))
    
    print("🤖 Bot started successfully!")
    app.run_polling()

if __name__ == '__main__':
    main()