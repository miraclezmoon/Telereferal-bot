# Overview

This is a Telegram referral bot system that implements a point-based reward mechanism. Users can invite friends through referral links, earn points for successful referrals, and redeem those points for various prizes. The bot features an interactive button-based interface that eliminates the need for typing commands, making it mobile-friendly and user-accessible. The system includes comprehensive admin controls for managing prizes and users, with built-in anti-fraud protection to prevent abuse.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework
- **Python Telegram Bot API**: Uses the `python-telegram-bot` library (v20.3) for handling Telegram interactions
- **Event-Driven Architecture**: Implements command handlers and callback query handlers for processing user interactions
- **Inline Keyboard Interface**: All user interactions are handled through clickable buttons rather than text commands

## Database Design
- **SQLite Database**: Lightweight file-based database (`referrals.db`) for data persistence
- **Four Core Tables**:
  - `users`: Stores user IDs and point balances
  - `referrals`: Tracks referrer-referred relationships for the referral system
  - `prizes`: Manages available rewards with points requirements and descriptions
  - `claimed_prizes`: Records prize redemption history with timestamps
- **Auto-initialization**: Database schema and default prizes are created automatically on first run

## Referral System Logic
- **Point Earning**: Users receive 5 points per successful referral
- **Anti-Fraud Measures**: Prevents self-referrals and duplicate referral claims
- **Real-time Tracking**: Immediate point updates and referral count display

## Prize Management System
- **Tiered Rewards**: 5-level prize system ranging from 50 to 1000 points
- **Dynamic Availability**: Prizes can be activated/deactivated by admins
- **One-Click Claiming**: Smart button interface shows only claimable prizes
- **Claim Tracking**: Prevents duplicate prize claims per user

## Admin Controls
- **Role-Based Access**: Admin functionality restricted to specific Telegram user IDs
- **Prize CRUD Operations**: Full create, read, update, delete capabilities for prizes
- **User Management**: Administrative control over user accounts and data

## Configuration Management
- **Environment Variables**: Bot token stored securely in `.env` file
- **Optional Dependencies**: Graceful fallback if `python-dotenv` is not available
- **Hardcoded Admin IDs**: Admin access configured directly in code for security

# External Dependencies

## Required Services
- **Telegram Bot API**: Core messaging and interaction platform requiring a bot token from @BotFather
- **SQLite**: Built-in Python database engine, no external setup required

## Python Libraries
- **python-telegram-bot (v20.3)**: Official Telegram Bot API wrapper for Python
- **python-dotenv (v1.0.0)**: Environment variable management for secure configuration

## Infrastructure Requirements
- **File System Access**: Required for SQLite database file storage and persistence
- **Network Connectivity**: Necessary for Telegram API communication
- **Python Runtime**: Compatible with Python 3.x environments

## Configuration Dependencies
- **Telegram Bot Token**: Must be obtained from Telegram's @BotFather
- **Admin User IDs**: Telegram user IDs must be manually configured in the code for administrative access